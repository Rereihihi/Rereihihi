import { Button } from "@/components/ui/button";
import { Monitor, Clock, Shield, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";
import heroCafe from "@/assets/hero-cafe.jpg";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen gradient-dark">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0">
          <img 
            src={heroCafe} 
            alt="Modern gaming internet cafe" 
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 container mx-auto px-4 py-20 text-center animate-fade-in">
          <div className="inline-block mb-6 px-6 py-2 bg-primary/20 border border-primary rounded-full">
            <span className="text-primary-glow font-semibold">🎮 Premium Gaming Experience</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary-glow animate-slide-up">
            Internet Café
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto animate-slide-up">
            จองเครื่องคอมพิวเตอร์ของคุณได้ง่ายๆ ด้วยระบบออนไลน์
            <br />
            สเปคแรง เกมส์ลื่น ไว ทันใจ
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <Button 
              variant="hero" 
              size="lg"
              onClick={() => navigate("/auth")}
              className="text-lg"
            >
              เริ่มจองเลย
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => navigate("/auth")}
              className="text-lg"
            >
              เข้าสู่ระบบ
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 gradient-primary bg-clip-text text-transparent">
            ทำไมต้องเลือกเรา?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <FeatureCard
              icon={<Monitor className="w-12 h-12 text-primary" />}
              title="สเปคแรง"
              description="คอมพิวเตอร์สเปคสูง RTX 4090 พร้อมเล่นทุกเกม"
            />
            <FeatureCard
              icon={<Clock className="w-12 h-12 text-primary" />}
              title="จองออนไลน์"
              description="จองเครื่องล่วงหน้าได้ ไม่ต้องมารอคิว"
            />
            <FeatureCard
              icon={<Shield className="w-12 h-12 text-primary" />}
              title="ปลอดภัย"
              description="ระบบชำระเงินที่ปลอดภัย พร้อม Access Code"
            />
            <FeatureCard
              icon={<Zap className="w-12 h-12 text-primary" />}
              title="รวดเร็ว"
              description="Internet ความเร็วสูง Ping ต่ำ เกมลื่นไหล"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="gradient-primary rounded-3xl p-12 shadow-glow text-center">
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              พร้อมเริ่มเล่นแล้วหรือยัง?
            </h2>
            <p className="text-xl mb-8 text-primary-foreground/90">
              สร้างบัญชีวันนี้ รับส่วนลดพิเศษ 20% สำหรับการจองครั้งแรก!
            </p>
            <Button 
              variant="secondary" 
              size="lg"
              onClick={() => navigate("/auth")}
              className="text-lg font-semibold"
            >
              สมัครสมาชิกฟรี
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

const FeatureCard = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => {
  return (
    <div className="bg-card p-6 rounded-xl shadow-card hover:shadow-glow transition-smooth border border-border">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
};

export default Index;
