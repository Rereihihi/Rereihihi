import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Loader2, QrCode, ArrowLeft, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@supabase/supabase-js";

interface Computer {
  id: string;
  computer_number: number;
  specs: string;
}

const Booking = () => {
  const { computerId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [computer, setComputer] = useState<Computer | null>(null);
  const [loading, setLoading] = useState(true);
  const [hours, setHours] = useState("1");
  const [step, setStep] = useState<"select" | "payment" | "success">("select");
  const [bookingId, setBookingId] = useState<string>("");
  const [accessCode, setAccessCode] = useState<string>("");

  useEffect(() => {
    checkUser();
    fetchComputer();
  }, [computerId]);

  const checkUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }
    setUser(user);
  };

  const fetchComputer = async () => {
    try {
      const { data, error } = await supabase
        .from("computers")
        .select("*")
        .eq("id", computerId)
        .single();

      if (error) throw error;
      setComputer(data);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "เกิดข้อผิดพลาด",
        description: "ไม่พบข้อมูลเครื่องคอมพิวเตอร์",
      });
      navigate("/dashboard");
    } finally {
      setLoading(false);
    }
  };

  const generateAccessCode = () => {
    return Math.random().toString(36).substring(2, 10).toUpperCase();
  };

  const handleCreateBooking = async () => {
    if (!user || !computer) return;

    setLoading(true);
    try {
      const code = generateAccessCode();
      const paymentDeadline = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now

      const { data, error } = await supabase
        .from("bookings")
        .insert({
          user_id: user.id,
          computer_id: computer.id,
          hours: parseInt(hours),
          access_code: code,
          status: "pending",
          payment_deadline: paymentDeadline.toISOString(),
        })
        .select()
        .single();

      if (error) throw error;

      setBookingId(data.id);
      setAccessCode(code);
      setStep("payment");

      toast({
        title: "สร้างการจองสำเร็จ",
        description: "กรุณาชำระเงินภายใน 10 นาที",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "เกิดข้อผิดพลาด",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePayment = async () => {
    setLoading(true);
    try {
      const startTime = new Date();
      const endTime = new Date(startTime.getTime() + parseInt(hours) * 60 * 60 * 1000);

      const { error } = await supabase
        .from("bookings")
        .update({
          status: "paid",
          start_time: startTime.toISOString(),
          end_time: endTime.toISOString(),
        })
        .eq("id", bookingId);

      if (error) throw error;

      // Update computer status
      await supabase
        .from("computers")
        .update({ status: "occupied" })
        .eq("id", computer?.id);

      setStep("success");

      toast({
        title: "ชำระเงินสำเร็จ",
        description: "บันทึกรหัสการเข้าใช้งานของคุณ",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "เกิดข้อผิดพลาด",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async () => {
    if (step === "payment" && bookingId) {
      try {
        await supabase
          .from("bookings")
          .update({ status: "cancelled" })
          .eq("id", bookingId);

        toast({
          title: "ยกเลิกการจองสำเร็จ",
        });
      } catch (error: any) {
        toast({
          variant: "destructive",
          title: "เกิดข้อผิดพลาด",
          description: error.message,
        });
      }
    }
    navigate("/dashboard");
  };

  if (loading && !computer) {
    return (
      <div className="min-h-screen gradient-dark flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  const hourPrice = 50;
  const totalPrice = parseInt(hours) * hourPrice;

  return (
    <div className="min-h-screen gradient-dark py-8 px-4">
      <div className="container mx-auto max-w-2xl">
        <Button variant="ghost" onClick={handleCancel} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          กลับ
        </Button>

        {step === "select" && (
          <Card className="shadow-glow">
            <CardHeader>
              <CardTitle className="text-2xl">จองเครื่องคอมพิวเตอร์</CardTitle>
              <CardDescription>
                เครื่องที่ {computer?.computer_number} - {computer?.specs}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <Label>เลือกจำนวนชั่วโมง</Label>
                <RadioGroup value={hours} onValueChange={setHours}>
                  {[1, 2, 3, 4, 5, 6].map((hour) => (
                    <div key={hour} className="flex items-center space-x-2">
                      <RadioGroupItem value={hour.toString()} id={`hour-${hour}`} />
                      <Label htmlFor={`hour-${hour}`} className="cursor-pointer">
                        {hour} ชั่วโมง - {hour * hourPrice} บาท
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <div className="bg-secondary p-4 rounded-lg">
                <div className="flex justify-between mb-2">
                  <span>ราคาต่อชั่วโมง:</span>
                  <span className="font-semibold">{hourPrice} บาท</span>
                </div>
                <div className="flex justify-between text-lg font-bold text-primary">
                  <span>ยอดรวม:</span>
                  <span>{totalPrice} บาท</span>
                </div>
              </div>

              <Button
                variant="hero"
                className="w-full"
                onClick={handleCreateBooking}
                disabled={loading}
              >
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                ดำเนินการจอง
              </Button>
            </CardContent>
          </Card>
        )}

        {step === "payment" && (
          <Card className="shadow-glow">
            <CardHeader>
              <CardTitle className="text-2xl">ชำระเงิน</CardTitle>
              <CardDescription>
                กรุณาชำระเงินภายใน 10 นาที มิฉะนั้นการจองจะถูกยกเลิกอัตโนมัติ
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-card p-8 rounded-lg text-center">
                <QrCode className="w-32 h-32 mx-auto text-primary mb-4" />
                <p className="text-sm text-muted-foreground">QR Code สำหรับชำระเงิน (Demo)</p>
                <p className="text-2xl font-bold text-primary mt-2">{totalPrice} บาท</p>
              </div>

              <div className="space-y-2 bg-secondary p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">รหัสการจอง:</p>
                <p className="text-2xl font-bold font-mono">{accessCode}</p>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={handleCancel}
                  disabled={loading}
                >
                  ยกเลิก
                </Button>
                <Button
                  variant="hero"
                  className="flex-1"
                  onClick={handlePayment}
                  disabled={loading}
                >
                  {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Demo Payment
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === "success" && (
          <Card className="shadow-glow border-success">
            <CardHeader>
              <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-10 h-10 text-success-foreground" />
              </div>
              <CardTitle className="text-2xl text-center">จองสำเร็จ!</CardTitle>
              <CardDescription className="text-center">
                บันทึกรหัสด้านล่างเพื่อใช้เข้าเครื่อง
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-primary/10 border-2 border-primary p-6 rounded-lg text-center">
                <p className="text-sm text-muted-foreground mb-2">Access Code</p>
                <p className="text-4xl font-bold font-mono text-primary">{accessCode}</p>
              </div>

              <div className="space-y-2 text-sm">
                <p>✅ เครื่องที่: {computer?.computer_number}</p>
                <p>✅ จำนวนชั่วโมง: {hours} ชั่วโมง</p>
                <p>✅ ยอดชำระ: {totalPrice} บาท</p>
              </div>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => navigate("/history")}
                >
                  ดูประวัติ
                </Button>
                <Button
                  variant="hero"
                  className="flex-1"
                  onClick={() => navigate("/dashboard")}
                >
                  กลับหน้าหลัก
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Booking;
