import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cpu, LogOut, History, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@supabase/supabase-js";

interface Computer {
  id: string;
  computer_number: number;
  specs: string;
  status: string;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [computers, setComputers] = useState<Computer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUser();
    fetchComputers();
  }, []);

  const checkUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }
    setUser(user);
  };

  const fetchComputers = async () => {
    try {
      const { data, error } = await supabase
        .from("computers")
        .select("*")
        .order("computer_number");

      if (error) throw error;
      setComputers(data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "เกิดข้อผิดพลาด",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast({
      title: "ออกจากระบบสำเร็จ",
      description: "แล้วพบกันใหม่!",
    });
    navigate("/");
  };

  const handleBooking = (computer: Computer) => {
    if (computer.status !== "available") {
      toast({
        variant: "destructive",
        title: "ไม่สามารถจองได้",
        description: "เครื่องนี้ไม่ว่างในขณะนี้",
      });
      return;
    }
    navigate(`/booking/${computer.id}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen gradient-dark flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen gradient-dark">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-lg sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold gradient-primary bg-clip-text text-transparent">
            Internet Café
          </h1>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate("/history")}>
              <History className="w-4 h-4 mr-2" />
              ประวัติ
            </Button>
            <Button variant="ghost" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              ออกจากระบบ
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">เลือกเครื่องคอมพิวเตอร์</h2>
          <p className="text-muted-foreground">คลิกเลือกเครื่องที่ต้องการเพื่อจอง</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {computers.map((computer) => (
            <Card
              key={computer.id}
              className={`shadow-card hover:shadow-glow transition-smooth cursor-pointer ${
                computer.status !== "available" ? "opacity-50" : ""
              }`}
              onClick={() => handleBooking(computer)}
            >
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="w-5 h-5 text-primary" />
                    เครื่องที่ {computer.computer_number}
                  </CardTitle>
                  <Badge
                    variant={computer.status === "available" ? "default" : "secondary"}
                    className={
                      computer.status === "available"
                        ? "bg-success text-success-foreground"
                        : ""
                    }
                  >
                    {computer.status === "available" ? "ว่าง" : "ไม่ว่าง"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-sm">
                  {computer.specs}
                </CardDescription>
                <Button
                  variant={computer.status === "available" ? "hero" : "secondary"}
                  className="w-full mt-4"
                  disabled={computer.status !== "available"}
                >
                  {computer.status === "available" ? "จองเลย" : "ไม่ว่าง"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
