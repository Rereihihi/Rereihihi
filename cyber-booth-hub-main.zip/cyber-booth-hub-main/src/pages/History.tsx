import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Loader2, Clock, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@supabase/supabase-js";

interface Booking {
  id: string;
  hours: number;
  access_code: string;
  status: string;
  start_time: string | null;
  end_time: string | null;
  created_at: string;
  computers: {
    computer_number: number;
    specs: string;
  };
}

const History = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUser();
    fetchBookings();
  }, []);

  const checkUser = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }
    setUser(user);
  };

  const fetchBookings = async () => {
    try {
      const { data, error } = await supabase
        .from("bookings")
        .select(`
          *,
          computers (
            computer_number,
            specs
          )
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setBookings(data || []);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "เกิดข้อผิดพลาด",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: "default" | "secondary" | "destructive" }> = {
      pending: { label: "รอชำระเงิน", variant: "secondary" },
      paid: { label: "ชำระแล้ว", variant: "default" },
      active: { label: "กำลังใช้งาน", variant: "default" },
      completed: { label: "เสร็จสิ้น", variant: "secondary" },
      cancelled: { label: "ยกเลิกแล้ว", variant: "destructive" },
    };

    const { label, variant } = statusMap[status] || { label: status, variant: "secondary" };
    return <Badge variant={variant}>{label}</Badge>;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("th-TH", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen gradient-dark flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen gradient-dark py-8 px-4">
      <div className="container mx-auto max-w-4xl">
        <Button variant="ghost" onClick={() => navigate("/dashboard")} className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          กลับ
        </Button>

        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">ประวัติการใช้งาน</h1>
          <p className="text-muted-foreground">ดูประวัติการจองและการชำระเงินของคุณ</p>
        </div>

        {bookings.length === 0 ? (
          <Card className="shadow-card">
            <CardContent className="py-16 text-center">
              <p className="text-muted-foreground mb-4">ยังไม่มีประวัติการใช้งาน</p>
              <Button variant="hero" onClick={() => navigate("/dashboard")}>
                จองเครื่องเลย
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {bookings.map((booking) => (
              <Card key={booking.id} className="shadow-card hover:shadow-glow transition-smooth">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>
                        เครื่องที่ {booking.computers.computer_number}
                      </CardTitle>
                      <CardDescription className="mt-1">
                        {booking.computers.specs}
                      </CardDescription>
                    </div>
                    {getStatusBadge(booking.status)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        จำนวนชั่วโมง
                      </p>
                      <p className="font-semibold">{booking.hours} ชั่วโมง</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">Access Code</p>
                      <p className="font-mono font-bold text-primary">{booking.access_code}</p>
                    </div>
                  </div>

                  {booking.start_time && (
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        เวลาเริ่มใช้งาน
                      </p>
                      <p className="font-semibold">{formatDate(booking.start_time)}</p>
                    </div>
                  )}

                  {booking.end_time && (
                    <div className="space-y-1">
                      <p className="text-sm text-muted-foreground">เวลาสิ้นสุด</p>
                      <p className="font-semibold">{formatDate(booking.end_time)}</p>
                    </div>
                  )}

                  <div className="pt-2 border-t border-border">
                    <p className="text-xs text-muted-foreground">
                      จองเมื่อ: {formatDate(booking.created_at)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default History;
