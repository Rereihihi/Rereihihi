-- Create profiles table for user information
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Create trigger to handle new user profiles
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'User')
  );
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Create computers table
CREATE TABLE public.computers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  computer_number INTEGER UNIQUE NOT NULL,
  specs TEXT NOT NULL,
  status TEXT DEFAULT 'available' CHECK (status IN ('available', 'occupied', 'maintenance')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Enable RLS for computers
ALTER TABLE public.computers ENABLE ROW LEVEL SECURITY;

-- Anyone can view computers
CREATE POLICY "Anyone can view computers"
  ON public.computers FOR SELECT
  USING (true);

-- Create bookings table
CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
  computer_id UUID REFERENCES public.computers(id) ON DELETE CASCADE NOT NULL,
  hours INTEGER NOT NULL CHECK (hours > 0 AND hours <= 12),
  access_code TEXT UNIQUE NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'active', 'completed', 'cancelled')),
  payment_deadline TIMESTAMP WITH TIME ZONE NOT NULL,
  start_time TIMESTAMP WITH TIME ZONE,
  end_time TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL
);

-- Enable RLS for bookings
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- Users can view their own bookings
CREATE POLICY "Users can view their own bookings"
  ON public.bookings FOR SELECT
  USING (auth.uid() = user_id);

-- Users can create their own bookings
CREATE POLICY "Users can create bookings"
  ON public.bookings FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own bookings
CREATE POLICY "Users can update their own bookings"
  ON public.bookings FOR UPDATE
  USING (auth.uid() = user_id);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Create trigger for bookings updated_at
CREATE TRIGGER update_bookings_updated_at
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create trigger for profiles updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample computers
INSERT INTO public.computers (computer_number, specs, status) VALUES
  (1, 'Intel i9-14900K, RTX 4090, 64GB RAM, 2TB NVMe SSD', 'available'),
  (2, 'Intel i9-14900K, RTX 4090, 64GB RAM, 2TB NVMe SSD', 'available'),
  (3, 'Intel i9-14900K, RTX 4090, 64GB RAM, 2TB NVMe SSD', 'available'),
  (4, 'Intel i9-14900K, RTX 4090, 64GB RAM, 2TB NVMe SSD', 'available'),
  (5, 'AMD Ryzen 9 7950X, RTX 4080, 32GB RAM, 1TB NVMe SSD', 'available'),
  (6, 'AMD Ryzen 9 7950X, RTX 4080, 32GB RAM, 1TB NVMe SSD', 'available'),
  (7, 'AMD Ryzen 9 7950X, RTX 4080, 32GB RAM, 1TB NVMe SSD', 'available'),
  (8, 'AMD Ryzen 9 7950X, RTX 4080, 32GB RAM, 1TB NVMe SSD', 'available'),
  (9, 'Intel i7-14700K, RTX 4070, 32GB RAM, 1TB NVMe SSD', 'available'),
  (10, 'Intel i7-14700K, RTX 4070, 32GB RAM, 1TB NVMe SSD', 'available'),
  (11, 'Intel i7-14700K, RTX 4070, 32GB RAM, 1TB NVMe SSD', 'available'),
  (12, 'Intel i7-14700K, RTX 4070, 32GB RAM, 1TB NVMe SSD', 'available');